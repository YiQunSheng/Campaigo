//package com.example.admin.campaigo.ui.activity;
//
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//
//import com.example.admin.campaigo.R;
//
//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }
//}
package com.example.admin.campaigo.ui.activity;

import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.example.admin.campaigo.R;
import com.example.admin.campaigo.model.Campaign;
import com.example.admin.campaigo.ui.fragment.campaignsFragment;
import com.example.admin.campaigo.ui.fragment.userFragment;
import com.example.admin.campaigo.ui.fragment.yoursFragment;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_main);

        final BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottom_navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        navigation.setSelectedItemId(R.id.navi_item_Campaigns);
    }
    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navi_item_Campaigns:
                    replaceFragment(new campaignsFragment());
                    return true;

                case R.id.navi_item_YoursCampaigns:
                    replaceFragment(new yoursFragment());
                    return true;

                case R.id.navi_item_UpCampaign:
                    replaceFragment(new userFragment());
                    return true;

                case R.id.navi_item_Users:
                    replaceFragment(new userFragment());
                    return true;
            }
            return false;
        }

    };
}
