package com.example.admin.campaigo.ui.fragment;

/**
 * Created by admin on 2017/12/17.
 */

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.fastjson.JSON;
import com.example.admin.campaigo.Adapter.CampaiAdapter;
import com.example.admin.campaigo.model.Campaign;
import com.example.admin.campaigo.model.User;
import com.example.admin.campaigo.network.HttpUtil;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Response;
import  com.example.admin.campaigo.R;
/**
 * Created by admin on 2017/12/15.
 */


public class yoursFragment extends Fragment {
    @Nullable
    List<Campaign> inCampaigns;
    static String DOMIN = "http://115.159.55.118/";
    String url;
    String CampaignsJson;
    String campaiJson;
    RecyclerView recyclerView;
    CampaiAdapter adapter;
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        url = DOMIN + "myList&id=" + getId();
        View view = inflater.inflate(R.layout.fragment_yours, container, false);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        inCampaigns = new ArrayList<>();
        recyclerView = (RecyclerView) view.findViewById(R.id.list_yours_campaigns);
        recyclerView.setLayoutManager(layoutManager);
        final BottomNavigationView navigation = (BottomNavigationView) view.findViewById(R.id.bottom_yours);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        inCampaigns = initCampaigns();
        navigation.setSelectedItemId(R.id.item_yours_comming);
        return view;
    }

    private List<Campaign> getPassedCampaigns(String CampaignsJson) {
        //此处传入用网络方法获得的Json（活动列表）,解析成List，返回已经结束的该同学已经参加的活动。
        List<Campaign> passedCampaigns = new ArrayList<>();
        List<Campaign> allCampaigns = new ArrayList<>();
        allCampaigns = JSON.parseArray(CampaignsJson, Campaign.class);
        for (Campaign campaign : allCampaigns) {
            passedCampaigns.add(campaign);
        }
        return  passedCampaigns;
    }
    public Boolean isPassTime(Campaign campaign) {
        //>0 前面的大于后面的。 返回1 现在的时间比活动开始时间后面，表示超时了。
        Timestamp currentTime = new Timestamp(System.currentTimeMillis());
        if (currentTime.compareTo(campaign.getStartline())>=0) {//现在时间比活动开始时间大或者等于
            Log.e("pass time", "no");
            return true;
        }
        Log.e("pass time", "yes");
        return false;
    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.item_yours_comming:
                    inCampaigns = initCampaigns();
                    for(int i=0;i<inCampaigns.size();i++) {
                        if (isPassTime(inCampaigns.get(i)))
                            inCampaigns.remove(i);
                        Log.e("pass!!!", inCampaigns.get(i).getCaname());

                    }
                    adapter = new CampaiAdapter(inCampaigns);
                    recyclerView.setAdapter(adapter);
                    return true;
                case R.id.item_yours_finished:
                    inCampaigns = initCampaigns();
                    for(int i=0;i<inCampaigns.size();i++) {
                        if (!isPassTime(inCampaigns.get(i)))
                            inCampaigns.remove(i);
                    }
                    adapter = new CampaiAdapter(inCampaigns);
                    recyclerView.setAdapter(adapter);
                    return true;
            }
            return false;
        }

    };

    private List<Campaign> initCampaigns() {
        new GetCampaingsTask().execute();
        List<Campaign> campaigns = new ArrayList<>();
//        campaigns = JSON.parseArray(CampaignsJson, Campaign.class);
        Campaign campaign1 = new Campaign();
        campaign1.setCaname("shengyiqun");
        campaign1.setStartline(new Timestamp(System.currentTimeMillis()+600000));
        campaign1.setEndline(new Timestamp(System.currentTimeMillis()));
        campaign1.setEndeadline(new Timestamp(System.currentTimeMillis()));
        campaign1.setDescribe("test1");
        Campaign campaign2 = new Campaign();
        campaign2.setCaname("SunZhao");
        campaign2.setStartline(new Timestamp(System.currentTimeMillis()));
        campaign2.setEndline(new Timestamp(System.currentTimeMillis()));
        campaign2.setEndeadline(new Timestamp(System.currentTimeMillis()));
        campaign2.setDescribe("test2");
        Campaign campaign3 = new Campaign();
        campaign3.setCaname("qianjingang");
        campaign3.setStartline(new Timestamp(System.currentTimeMillis()));
        campaign3.setEndline(new Timestamp(System.currentTimeMillis()));
        campaign3.setEndeadline(new Timestamp(System.currentTimeMillis()));
        campaign3.setDescribe("test3");
        campaigns.add(campaign1);
        campaigns.add(campaign2);
        campaigns.add(campaign3);
        return campaigns;
    }
    class GetCampaingsTask extends AsyncTask<Void, Integer, Boolean> {
        @Override
        protected void onPreExecute() {
            Log.e("PreExecute", "Success");
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            Log.e("PostExecute", "Success");
        }

        @Override
        protected void onProgressUpdate(Integer... values) {

        }

        @Override
        protected Boolean doInBackground(Void... voids) {
            HttpUtil.sendOkHttpRequest(url, new okhttp3.Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Log.e("Error", "Net Error");
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    CampaignsJson = response.body().string();
                }
            });
            return null;
        }
    }
    private String UserPreferencetoJson() {
        SharedPreferences pref = getActivity().getSharedPreferences("user_Info", getActivity().MODE_PRIVATE);
        String json = pref.getString("User_Json", "");
        return json;
    }

    private String getUserId() {
        String UserJson = UserPreferencetoJson();
        User user = JSON.parseObject(UserJson, User.class);
        return user.getId();
    }
}
