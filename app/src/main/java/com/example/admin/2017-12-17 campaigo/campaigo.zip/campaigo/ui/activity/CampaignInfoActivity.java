package com.example.admin.campaigo.ui.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.admin.campaigo.R;

public class CampaignInfoActivity extends AppCompatActivity {
    TextView text_name;
    TextView text_start;
    TextView text_end ;
    TextView text_ended ;
    TextView text_describe ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campaign_info);
         text_name= (TextView) findViewById(R.id.text_campaignInfo_name);
        text_start = (TextView) findViewById(R.id.text_campaignInfo_start);
        text_end = (TextView) findViewById(R.id.text_campaignInfo_end);
        text_ended = (TextView) findViewById(R.id.text_campaignInfo_endedtime);
        text_describe = (TextView) findViewById(R.id.text_campaignInfo_describe);
        Intent intent = getIntent();
        text_name.setText(intent.getStringExtra("name"));
        text_start.setText(intent.getStringExtra("startTime"));
        text_end.setText(intent.getStringExtra("endTime"));
        text_ended.setText(intent.getStringExtra("endedTime"));
        text_describe.setText(intent.getStringExtra("describe"));

    }
}
