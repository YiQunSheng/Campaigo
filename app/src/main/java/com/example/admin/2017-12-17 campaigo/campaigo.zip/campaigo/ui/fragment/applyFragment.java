package com.example.admin.campaigo.ui.fragment;

/**
 * Created by admin on 2017/12/15.
 */

public class applyFragment {
}
